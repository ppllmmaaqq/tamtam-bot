<?php

// حفظ الرسالة في log.txt
file_put_contents("log.txt", file_get_contents("php://input") . "\n", FILE_APPEND);

// فك البيانات القادمة
$data = json_decode(file_get_contents("php://input"), true);
$message = $data['message']['body'] ?? '';
$user_id = $data['message']['recipient']['user_id'] ?? null;

if ($message && $user_id) {
    // الرد بنفس الرسالة
    $token = 'f9LHodD0cOL9Ikvear8nlHympQ-vTx2tAoTRWaKxKrJcY6Pm7p-IQyqrsNRqOBTz5yKllXQjtsFkEq5wNeUbbg';

    $response = [
        "recipient" => ["user_id" => $user_id],
        "message" => ["body" => $message]
    ];

    $ch = curl_init("https://botapi.tamtam.chat/messages?access_token=$token");
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($response));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
    ]);
    curl_exec($ch);
    curl_close($ch);
}
?>
